The Nano-RK real time operating system has been ported to the mbed (LPC1768) platform and is released here as mRK (mbed-Resource Kernel)
The porting was done by mLab-The Real Time and Embedded Systems Lab at the University of Pennsylvania.

Contributing Authors 

- Abhijeet Mulay
- Dalton Banks
- Madhur Behl
- Paul Gurniak

(C) 2012

Nano-RK, a real-time operating system for sensor networks.
Copyright (C) 2007, Real-Time and Multimedia Lab, Carnegie Mellon University
All rights reserved.
 
 